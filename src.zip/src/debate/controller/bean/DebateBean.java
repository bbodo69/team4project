package debate.controller.bean;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/debate/")
public class DebateBean{

	@RequestMapping("debateBoard.do")
	public String test() throws Exception{
		
		return "debate/debateBoard";
	}
	
		
}

