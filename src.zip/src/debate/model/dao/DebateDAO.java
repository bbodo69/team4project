package debate.model.dao;

public class DebateDAO {

}
