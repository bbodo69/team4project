package debate.model.vo;

public class DebateVO {

}
